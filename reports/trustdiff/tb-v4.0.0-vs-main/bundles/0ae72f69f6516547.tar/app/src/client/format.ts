export function formatName(name: string): string {
  return name.trim().replace(/\s+/g, " ");
}
